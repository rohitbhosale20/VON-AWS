package com.aws.von.controller;
// import com.VectorOneNine.Search.Repo.dataRepo;
import com.aws.von.entity.Data;
import com.aws.von.repository.dataRepository;
import com.aws.von.service.dataService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/search/*")
public class dataController {

	@Autowired
	public dataRepository dataRepository;
	
	@GetMapping("list")
	public List<Data> list(@RequestParam(value = "state", required = false)String state,
						@RequestParam(value = "postcode", required = false)String postcode){
		
		Specification<Data> specification=dataService.getService(state, postcode);

		return dataRepository.findAll(specification);
	
	}
	
}

