package com.aws.von.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="von_csv1")
public class Data {
	
	public Data() {
		
	}

	@Id
	@Column(name="firstName")
	private String firstName;
	
	@Column(name="lastName")
	private String lastName;
	
	@Column(name="jobtitle")
	private String jobtitle;
	
	@Column(name="industry")
	private String industry;
	
	@Column(name="state")
	private String state;
	
	@Column(name="postcode")
	private String postcode;
	
	@Column(name="telephone")
	private String telephone;
	
	@Column(name="companysize")
	private String companysize;
	
	@Column(name="job_level__c")
	private String job_level__c;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getJobtitle() {
		return jobtitle;
	}

	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getCompanysize() {
		return companysize;
	}

	public void setCompanysize(String companysize) {
		this.companysize = companysize;
	}

	public String getJob_level__c() {
		return job_level__c;
	}

	public void setJob_level__c(String job_level__c) {
		this.job_level__c = job_level__c;
	}
}

