package com.aws.von.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aws.von.entity.Data;

@Repository
public interface dataRepository extends JpaRepository<Data, String> {

	List<Data> findAll(Specification<Data> specification);

	
}
